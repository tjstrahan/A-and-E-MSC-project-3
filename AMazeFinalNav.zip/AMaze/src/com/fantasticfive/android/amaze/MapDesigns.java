/*********************************************************************************
 *********************************************************************************
 **        D O     N O T     D O     C R T L - S H I F T - F     H E R E        **
 *********************************************************************************
 *********************************************************************************/

package com.fantasticfive.android.amaze;

// imports
import java.util.List;
import java.util.LinkedList;

import static com.fantasticfive.android.amaze.Wall.*;

/**
 * Class containing all the map designs
 * @author FantasticFive
 *
 */
public final class MapDesigns {

	// LinkedList of the MapDesign objects
	public static final List<MapDesign> designList = new LinkedList<MapDesign>();
	
	static {
		
        designList.add(new MapDesign(
    			"APPvengers",
    			36, 38,
    			new int[][] {
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0},
    					{0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0},
    					{0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0},
    					{0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0},
    					{0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0},
    					{0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0},
    					{0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0},
    					{0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0},
    					{0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0},
    					{0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, 0, LEFT|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0},
    					{0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0},
    					{0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0},
    					{0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, 0, 0, LEFT|BOTTOM|RIGHT, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, LEFT|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, BOTTOM|RIGHT, 0, 0, 0, 0, TOP|BOTTOM|LEFT|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, TOP|BOTTOM|RIGHT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    
    			},
    			new int[][] {
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    			
    			},
    			8, 35,
    		    // NEW SET RGB colour
    		    0,0,0
    	));    
		

		// instantiate a new MapDesign and add it to the LinkedList
		designList.add(new MapDesign(
				
			// name of map	
			"Iron Man",
			
			// size of map
	        6, 6,
	        
	        // position of walls in map
	        new int[][] {
	                {LEFT|TOP|RIGHT, TOP, TOP|BOTTOM, TOP, TOP|RIGHT, TOP|RIGHT},
	                {LEFT, 0, 0, 0, BOTTOM, RIGHT},
	                {LEFT|RIGHT, RIGHT, RIGHT|BOTTOM, BOTTOM, 0, RIGHT|BOTTOM},
	                {LEFT|BOTTOM, 0, RIGHT, RIGHT, 0, RIGHT},
	                {LEFT, 0, 0, 0, 0, RIGHT|BOTTOM},
	                {LEFT|BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT, BOTTOM, BOTTOM, RIGHT|BOTTOM}
	        },
	        
	        // position of goal in map
	        new int[][] {
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 1, 0, 0},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0}
	        },
	        
	        // initial position of ball in map
	        2, 2, 176,0,0
		));

        designList.add(new MapDesign(
	        "Captain A",
	        6, 6,
	        new int[][] {
	                {LEFT|TOP, TOP, TOP|RIGHT|BOTTOM, TOP, TOP, TOP|RIGHT|BOTTOM},
	                {LEFT|BOTTOM, 0, BOTTOM, 0, 0, RIGHT},
	                {LEFT, 0, 0, 0, RIGHT, RIGHT|BOTTOM},
	                {LEFT, 0, RIGHT, BOTTOM, 0, RIGHT},
	                {LEFT|RIGHT|BOTTOM, 0, 0, 0, 0, RIGHT},
	                {LEFT|BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT, BOTTOM|RIGHT}
	        },
	        new int[][] {
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 1},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0}
	        },
	        0, 3, 255,255,255
		));
        
        designList.add(new MapDesign(
    		"Thor",
            7, 7,
            new int[][] {
                    {LEFT|TOP, TOP, TOP, TOP|BOTTOM, TOP|RIGHT, TOP, TOP|RIGHT},
                    {LEFT|BOTTOM, RIGHT, 0, 0, BOTTOM, 0, RIGHT|BOTTOM},
                    {LEFT|BOTTOM, 0, RIGHT, 0, 0, 0, RIGHT},
                    {LEFT, 0, 0, 0, RIGHT|BOTTOM, 0, RIGHT|BOTTOM},
                    {LEFT, BOTTOM, RIGHT, 0, 0, 0, BOTTOM|RIGHT},
                    {LEFT|BOTTOM, RIGHT, 0, 0, 0, BOTTOM, RIGHT},
                    {LEFT|BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT}
            },
            new int[][] {
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 1},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0}
            },
            0, 2, 200,200,200
        ));

        designList.add(new MapDesign(
    		"Hawkeye",
            7, 7,
            new int[][] {
                    {LEFT|TOP|RIGHT, TOP, TOP|BOTTOM, TOP|RIGHT, TOP, TOP, TOP|RIGHT|BOTTOM},
                    {LEFT, 0, 0, 0, 0, 0, RIGHT},
                    {LEFT, BOTTOM, RIGHT, 0, 0, RIGHT, RIGHT},
                    {LEFT, 0, 0, RIGHT|BOTTOM, RIGHT, 0, RIGHT|BOTTOM},
                    {LEFT|BOTTOM, 0, 0, 0, BOTTOM, 0,  RIGHT},
                    {LEFT, RIGHT, RIGHT|BOTTOM, 0, 0, 0, RIGHT},
                    {LEFT|BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
            },
            new int[][] {
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 1, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0}
            },
            4, 1, 153,50,204
        ));
      
        designList.add(new MapDesign(
	        "Black Widow",
	        7, 7,
	        new int[][] {
	                {LEFT|TOP|RIGHT, TOP|BOTTOM, TOP|RIGHT, TOP, TOP, TOP|RIGHT, TOP|RIGHT},
	                {LEFT|BOTTOM, 0, 0, 0, RIGHT|BOTTOM, 0, RIGHT},
	                {LEFT, BOTTOM, 0, 0, 0, BOTTOM, RIGHT},
	                {LEFT|BOTTOM, 0, RIGHT, RIGHT, 0, 0, RIGHT},
	                {LEFT, RIGHT, BOTTOM, 0, 0, 0, BOTTOM|RIGHT},
	                {LEFT, 0, 0, BOTTOM|RIGHT, BOTTOM, 0, RIGHT},
	                {LEFT|BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
	        },
	        new int[][] {
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 1}
	        },
	        0, 0, 0, 0, 0
        ));

        
    	designList.add(new MapDesign(
                "The Hulk",
                10, 10,
                new int[][] {
                        {LEFT|TOP|RIGHT, TOP, TOP, TOP, TOP, TOP|BOTTOM, TOP|RIGHT, TOP, TOP|RIGHT, TOP|RIGHT},
                        {LEFT, RIGHT, 0, 0, 0, 0, 0, 0, 0, BOTTOM|RIGHT},
                        {LEFT|BOTTOM, 0, 0, BOTTOM|RIGHT, 0, 0, BOTTOM|RIGHT, BOTTOM, 0, RIGHT},
                        {LEFT, 0, BOTTOM|RIGHT, 0, 0, 0, RIGHT, 0, 0, RIGHT},
                        {LEFT|BOTTOM, 0, BOTTOM, RIGHT, 0, 0, BOTTOM, 0, BOTTOM|RIGHT, RIGHT},
                        {LEFT, BOTTOM, 0, 0, RIGHT, 0, 0, BOTTOM, RIGHT, RIGHT},
                        {LEFT, 0, BOTTOM|RIGHT, BOTTOM, 0, 0, BOTTOM|RIGHT, 0, 0, BOTTOM|RIGHT},
                        {LEFT|BOTTOM, 0, RIGHT, 0, 0, BOTTOM|RIGHT, 0, 0, 0, BOTTOM|RIGHT},
                        {LEFT, 0, BOTTOM, 0, 0, 0, RIGHT, BOTTOM, 0, RIGHT},
                        {LEFT|BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
                },
                new int[][] {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
                },
                0, 0, 0, 1, 280
        ));

    	designList.add(new MapDesign(
                "Loki",
                10, 10,
                new int[][] {
                        {LEFT|TOP|RIGHT, TOP|BOTTOM, TOP, TOP|RIGHT, TOP, TOP, TOP|RIGHT, TOP, TOP, TOP|RIGHT|BOTTOM},
                        {LEFT, RIGHT, 0, 0, 0, 0, BOTTOM, 0, BOTTOM|RIGHT, RIGHT},
                        {LEFT|RIGHT, 0, BOTTOM|RIGHT, 0, RIGHT, 0, 0, 0, BOTTOM, RIGHT},
                        {LEFT, 0, RIGHT, 0, 0, 0, RIGHT, 0, 0, BOTTOM|RIGHT},
                        {LEFT|BOTTOM, 0, 0, 0, BOTTOM|RIGHT, BOTTOM, 0, 0, RIGHT, RIGHT},
                        {LEFT|RIGHT, RIGHT, 0, BOTTOM, RIGHT, 0, 0, 0, BOTTOM, RIGHT},
                        {LEFT, BOTTOM, 0, 0, 0, 0, 0, BOTTOM, 0, BOTTOM|RIGHT},
                        {LEFT, BOTTOM, BOTTOM, RIGHT, RIGHT, BOTTOM, 0, 0, 0, RIGHT},
                        {LEFT|BOTTOM|RIGHT, 0, 0, 0, 0, BOTTOM, RIGHT, RIGHT, BOTTOM, RIGHT},
                        {LEFT|BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
                },
                new int[][] {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 1}
                },
                0, 0, 34, 139, 34
        ));

    	designList.add(new MapDesign(
                "Thanos",
                10, 10,
                new int[][] {
                        {LEFT|TOP|RIGHT, TOP|BOTTOM, TOP, TOP, TOP|RIGHT, TOP, TOP, TOP|BOTTOM, TOP|RIGHT, TOP|RIGHT},
                        {LEFT, 0, RIGHT, 0, 0, 0, 0, 0, 0, RIGHT},
                        {LEFT, 0, 0, 0, BOTTOM, 0, BOTTOM|RIGHT, 0, BOTTOM, RIGHT},
                        {LEFT|RIGHT, 0, BOTTOM, 0, BOTTOM, 0, 0, 0, RIGHT, RIGHT},
                        {LEFT|BOTTOM, 0, 0, 0, RIGHT, RIGHT, 0, 0, BOTTOM, RIGHT},
                        {LEFT|RIGHT, RIGHT, 0, 0, 0, BOTTOM, 0, BOTTOM, 0, RIGHT},
                        {LEFT, 0, 0, BOTTOM, 0, BOTTOM, 0, 0, RIGHT, RIGHT},
                        {LEFT|RIGHT, 0, 0, RIGHT, BOTTOM, 0, 0, 0, 0, BOTTOM|RIGHT},
                        {LEFT|BOTTOM, 0, 0, 0, RIGHT, 0, BOTTOM, RIGHT, BOTTOM, RIGHT},
                        {LEFT|BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
                },
                new int[][] {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 1, 0}
                },
                1, 0, 255,215,0
        ));
        
		
		designList.add(new MapDesign(
				"Nick Fury",
				6, 6,
				new int[][] {
						{LEFT|TOP|RIGHT, TOP, TOP|RIGHT, TOP, TOP, TOP|RIGHT},
						{LEFT|BOTTOM, 0, BOTTOM, RIGHT, 0, BOTTOM|RIGHT},
						{LEFT|RIGHT, 0, 0, 0, 0, RIGHT},
						{LEFT|BOTTOM, 0, RIGHT, BOTTOM, RIGHT, BOTTOM|RIGHT},
						{LEFT, 0, BOTTOM, 0, 0, RIGHT},
						{LEFT|BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT}
				},
				new int[][] {
						{0, 0, 0, 1, 0, 0},
						{1, 0, 0, 0, 0, 0},
						{0, 0, 0, 0, 0, 0},
						{0, 0, 0, 0, 0, 1},
						{1, 0, 0, 0, 0, 1},
						{0, 0, 0, 1, 0, 0}
				},
				0, 2, 0,0,0
		));
		
		
		
		designList.add(new MapDesign(
	            "Ultron",
	            7, 7,
	            new int[][] {
	                    {LEFT|TOP, TOP|RIGHT, TOP, TOP|RIGHT, TOP, TOP|BOTTOM, TOP|RIGHT},
	                    {LEFT|BOTTOM, 0, 0, BOTTOM, 0, 0, RIGHT},
	                    {LEFT, BOTTOM, 0, RIGHT, 0, 0, BOTTOM|RIGHT},
	                    {LEFT, 0, BOTTOM|RIGHT, 0, BOTTOM, 0, RIGHT|BOTTOM},
	                    {LEFT|BOTTOM, 0, 0, 0, RIGHT, 0, RIGHT},
	                    {LEFT|RIGHT, 0, 0, 0, 0, BOTTOM, RIGHT},
	                    {LEFT|BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM|RIGHT}
	            },
	            new int[][] {
	                    {0, 1, 0, 1, 0, 1, 0},
	                    {0, 0, 0, 0, 0, 0, 0},
	                    {0, 0, 0, 0, 0, 0, 0},
	                    {1, 0, 0, 1, 0, 0, 1},
	                    {0, 0, 0, 0, 0, 0, 0},
	                    {0, 0, 0, 0, 0, 0, 0},
	                    {0, 1, 0, 1, 0, 1, 0}
	            },
	            6, 4, 169, 169, 169
		));
		
		designList.add(new MapDesign(
	            "Scarlett Witch",
	            8, 8,
	            new int[][] {
	                    {LEFT|TOP, TOP|BOTTOM, TOP|BOTTOM, TOP, TOP|BOTTOM, TOP|RIGHT, TOP, TOP|RIGHT},
	                    {LEFT, 0, 0, RIGHT, 0, 0, BOTTOM, RIGHT},
	                    {LEFT, RIGHT, 0, BOTTOM, 0, 0, RIGHT, RIGHT},
	                    {LEFT, 0, BOTTOM, 0, RIGHT, BOTTOM, 0, RIGHT},
	                    {LEFT, RIGHT, 0, 0, BOTTOM, 0, 0, RIGHT|BOTTOM},
	                    {LEFT|RIGHT|BOTTOM, 0, 0, BOTTOM, 0, 0, BOTTOM, RIGHT},
	                    {LEFT, 0, 0, 0, 0, BOTTOM|RIGHT, 0, RIGHT},
	                    {LEFT|BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM|RIGHT}
	            },
	            new int[][] {
	                    {0, 0, 0, 1, 0, 0, 1, 0},
	                    {1, 0, 0, 0, 1, 0, 0, 0},
	                    {0, 0, 0, 0, 0, 0, 1, 0},
	                    {0, 0, 0, 1, 0, 1, 0, 0},
	                    {0, 0, 0, 0, 0, 0, 0, 1},
	                    {1, 0, 1, 0, 0, 0, 0, 0},
	                    {0, 0, 0, 0, 0, 1, 1, 0},
	                    {0, 1, 0, 1, 0, 0, 0, 1}
	            },
	            4, 5, 80, 0, 0
		));

		designList.add(new MapDesign(
	            "QuickSilver",
	            8, 8,
	            new int[][] {
	                    {LEFT|TOP, TOP|BOTTOM, TOP, TOP, TOP|RIGHT, TOP|BOTTOM, TOP, TOP|RIGHT},
	                    {LEFT, 0, BOTTOM|RIGHT, 0, 0, 0, BOTTOM, RIGHT},
	                    {LEFT|BOTTOM, 0, 0, 0, RIGHT, 0, 0, RIGHT},
	                    {LEFT, 0, RIGHT, BOTTOM, 0, 0, 0, RIGHT},
	                    {LEFT, 0, 0, 0, 0, RIGHT, RIGHT, RIGHT|BOTTOM},
	                    {LEFT, RIGHT, BOTTOM, 0, 0, 0, 0, RIGHT},
	                    {LEFT|RIGHT, BOTTOM, 0, 0, 0, BOTTOM, RIGHT, RIGHT},
	                    {LEFT|BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT, BOTTOM, BOTTOM, BOTTOM, BOTTOM|RIGHT}
	            },
	            new int[][] {
	                    {0, 0, 0, 0, 1, 0, 0, 0},
	                    {0, 1, 0, 0, 0, 0, 0, 1},
	                    {0, 0, 0, 0, 0, 0, 1, 0},
	                    {1, 0, 0, 1, 0, 0, 0, 1},
	                    {0, 0, 0, 0, 0, 1, 0, 0},
	                    {0, 0, 0, 0, 0, 0, 0, 0},
	                    {0, 0, 1, 0, 1, 0, 0, 0},
	                    {1, 0, 0, 0, 0, 0, 1, 0}
	            },
	            3, 5, 112,112,112
		));

	}
	
	private MapDesigns() {
	    throw new AssertionError();
	}
}
