package com.fantasticfive.android.amaze;

/**
 * Messages Class
 * 
 * @author The Appvengers
 * 
 */
public final class Messages {
	/**
	 * Constant to store the invalidate message as an int
	 */
	public static final int MSG_INVALIDATE = 1;
	/**
	 * Constant to store the reached wall message as an int
	 */
	public static final int MSG_REACHED_WALL = 2;
	/**
	 * Constant to store the reached goal message as an int
	 */
	public static final int MSG_REACHED_GOAL = 3;
	/**
	 * Constant to store the restart message as an int
	 */
	public static final int MSG_RESTART = 4;
	/**
	 * Constant to store the previous map message as an int
	 */
	public static final int MSG_MAP_PREVIOUS = 5;
	/**
	 * Constant to store the next map message as an int
	 */
	public static final int MSG_MAP_NEXT = 6;
}
