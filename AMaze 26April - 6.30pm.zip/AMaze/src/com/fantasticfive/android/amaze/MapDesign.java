package com.fantasticfive.android.amaze;

/**
 * Map design class
 * 
 * @author The Appvengers
 * 
 */
public class MapDesign {

	// declaring private variables
	/**
	 * Int to store the Map name
	 */
	private String mName;
	/**
	 * Int to store the size X
	 */
	private int mSizeX = 0;
	/**
	 * Int to store the size Y
	 */
	private int mSizeY = 0;
	/**
	 * Array to store the walls
	 */
	private int[][] mWalls;
	/**
	 * Array to store the goals
	 */
	private int[][] mGoals;
	/**
	 * Int to store initial position x
	 */
	private int mInitialPositionX;
	/**
	 * Int to store initial position y
	 */
	private int mInitialPositionY;
	/**
	 * Int to store the goal count
	 */
	private int mGoalCount = 0;
	/**
	 * Int to store the colour red
	 */
	private int mRed = 0;
	/**
	 * Int to store the colour green
	 */
	private int mGreen = 0;
	/**
	 * Int to store the colour blue
	 */
	private int mBlue = 0;

	/**
	 * Constructor with arguments
	 * 
	 * @param name
	 * @param sizeX
	 * @param sizeY
	 * @param walls
	 * @param goals
	 * @param initialPositionX
	 * @param initialPositionY
	 */
	public MapDesign(String name, int sizeX, int sizeY, int[][] walls,
			int[][] goals, int initialPositionX, int initialPositionY, int red,
			int blue, int green) {
		mName = name;
		mSizeX = sizeX;
		mSizeY = sizeY;
		mWalls = walls;
		mGoals = goals;
		mRed = red;
		mGreen = green;
		mBlue = blue;
		mInitialPositionX = initialPositionX;
		mInitialPositionY = initialPositionY;
		for (int y = 0; y < mSizeY; y++) {
			for (int x = 0; x < mSizeX; x++) {
				mGoalCount = mGoalCount + mGoals[y][x];
			}
		}
	}

	/**
	 * Method to get the name
	 * 
	 * @return
	 */
	public String getName() {
		return mName;
	}

	/**
	 * Method to get the walls
	 * 
	 * @return
	 */
	public int[][] getWalls() {
		return mWalls;
	}

	/**
	 * Method to get walls at specific position
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public int getWalls(int x, int y) {
		return mWalls[y][x];
	}

	/**
	 * Method to get goals
	 * 
	 * @return
	 */
	public int[][] getGoals() {
		return mGoals;
	}

	/**
	 * Method to get goal count
	 * 
	 * @return
	 */
	public int getGoalCount() {
		return mGoalCount;
	}

	/**
	 * Method to get size X
	 * 
	 * @return
	 */
	public int getSizeX() {
		return mSizeX;
	}

	/**
	 * Method to get size Y
	 * 
	 * @return
	 */
	public int getSizeY() {
		return mSizeY;
	}

	/**
	 * Method to get initial position X
	 * 
	 * @return
	 */
	public int getInitialPositionX() {
		return mInitialPositionX;
	}

	/**
	 * Method to get initial position Y
	 * 
	 * @return
	 */
	public int getInitialPositionY() {
		return mInitialPositionY;
	}

	/*
	 * to allow Red component of RGB colour to be set for background - this and
	 * blue and green where implemented before we decided to use a background
	 * image
	 */
	/**
	 * Method to get red
	 * 
	 * @return
	 */
	public int getRed() {
		return mRed;
	}

	/**
	 * Method to get green
	 * 
	 * @return
	 */
	public int getGreen() {
		return mGreen;
	}

	/**
	 * Method to get blue
	 * 
	 * @return
	 */
	public int getBlue() {
		return mBlue;
	}
}
