package com.fantasticfive.android.amaze;

/**
 * Map Class
 * 
 * @author The Appvengers
 * 
 */
public class Map {

	/**
	 * Private instantiation of the map design class
	 */
	private MapDesign mDesign;

	/**
	 * Setting up 2d array for goals
	 */
	private int[][] mGoals;

	/**
	 * Int to store the goal count
	 */
	private int mGoalCount;

	/**
	 * Constructor with arguments
	 * 
	 * @param design
	 */
	public Map(MapDesign design) {
		mDesign = design;
		// calling the init method
		init();
	}

	/**
	 * Method to determine number of goals and position of goals on any given
	 * map
	 */
	public void init() {

		// if mGoals array is null create array with these values
		if (mGoals == null)
			mGoals = new int[mDesign.getSizeY()][mDesign.getSizeX()];

		
		//setting the goals by using the call to the mDesign class and using
		// the get goals method from it
		int[][] goals = mDesign.getGoals();

		// for loop which will work out the size of the map
		for (int y = 0; y < mDesign.getSizeY(); y++)
			for (int x = 0; x < mDesign.getSizeX(); x++)

				// assign the goals from the map design to the mGoals variable
				mGoals[y][x] = goals[y][x];

		// call the mDesign class to get the count on the number of goals
		mGoalCount = mDesign.getGoalCount();
	}

	/**
	 * Method to get the name of the map
	 * 
	 * @return
	 */
	public String getName() {
		return mDesign.getName();
	}

	/**
	 * Method to get the walls in the map
	 * 
	 * @return
	 */
	public int[][] getWalls() {
		return mDesign.getWalls();
	}

	/**
	 * Method that gets outer walls of map
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public int getWalls(int x, int y) {
		return mDesign.getWalls(x, y);
	}

	/**
	 * Method which will return the goals
	 * 
	 * @return
	 */
	public int[][] getGoals() {
		return mGoals;
	}

	/**
	 * Method returns the goals position
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public int getGoal(int x, int y) {
		return mGoals[y][x];
	}

	/**
	 * Method to remove the goal once it has been found
	 * 
	 * @param x
	 * @param y
	 */
	public void removeGoal(int x, int y) {
		mGoalCount = mGoalCount - mGoals[y][x];
		mGoals[y][x] = 0;
	}

	/**
	 * Method to set the goal count
	 * 
	 * @param x
	 * @param y
	 * @param value
	 */
	public void setGoal(int x, int y, int value) {
		mGoalCount = mGoalCount - (mGoals[y][x] - value);
		mGoals[y][x] = value;
	}

	/**
	 * Method to get sizeX with a call to the Map Design class
	 * 
	 * @return
	 */
	public int getSizeX() {
		return mDesign.getSizeX();
	}

	/**
	 * Method to get sizeY with a call to the Map Design class
	 * 
	 * @return
	 */
	public int getSizeY() {
		return mDesign.getSizeY();
	}

	/**
	 * Method to get initialPositionX with a class to the Map Design class
	 * 
	 * @return
	 */
	public int getInitialPositionX() {
		return mDesign.getInitialPositionX();
	}

	/**
	 * Method to get initialPositionY with a call to the Map Design class
	 * 
	 * @return
	 */
	public int getInitialPositionY() {
		return mDesign.getInitialPositionY();
	}

	/**
	 * Method to get the goal count
	 * 
	 * @return
	 */
	public int getGoalCount() {
		return mGoalCount;
	}
}
