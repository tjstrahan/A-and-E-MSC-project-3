
package com.fantasticfive.android.amaze;

/**
 * @author The Appvengers
 * Enum to store the direction the ball can move in
 */
public enum Direction {
	NONE,
	LEFT,
	RIGHT,
	UP,
	DOWN
}
