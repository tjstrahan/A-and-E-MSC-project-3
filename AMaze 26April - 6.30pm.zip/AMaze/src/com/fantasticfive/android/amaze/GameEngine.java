package com.fantasticfive.android.amaze;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Vibrator;
import android.os.Handler;
import android.os.Message;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.widget.TextView;

/**
 * 
 * @author FantasticFive
 * 
 */
@SuppressWarnings("deprecation")
public class GameEngine {
	/**
	 * Instantiation of the Sensor Manager object
	 */
	private SensorManager mSensorManager;
	/**
	 * Instantiation of the Vibrator object
	 */
	private Vibrator mVibrator;
	/**
	 * Float to store the acceleration threshold
	 */
	private static float ACCEL_THRESHOLD = 2;
	/**
	 * Float to store accel x
	 */
	private float mAccelX = 0;
	/**
	 * Float to store accel y
	 */
	private float mAccelY = 0;
	/**
	 * Instantiation of the Handler object
	 */
	private Handler mHandler;
	/**
	 * Instantiation of the Map class
	 */
	private Map mMap;
	/**
	 * Instantiation of the Ball class
	 */
	private Ball mBall;
	/**
	 * Int to store the current map
	 */
	private int mCurrentMap = 0;
	/**
	 * Int to store the map to load
	 */
	private int mMapToLoad = 0;
	/**
	 * Int to store the step count
	 */
	private int mStepCount = 0;
	/**
	 * Instantiation of the Direction class, set to none
	 */
	private Direction mCommandedRollDirection = Direction.NONE;
	/**
	 * TextView to store the maze name label
	 */
	private TextView mMazeNameLabel;
	/**
	 * TextView to store the remaining goals label
	 */
	private TextView mRemainingGoalsLabel;
	/**
	 * TextView to steps view
	 */
	private TextView mStepsView;
	/**
	 * MazeView to store the maze layout
	 */
	private MazeView mMazeView;
	/**
	 * Alert dialog to store the maze solved dialog
	 */
	private final AlertDialog mMazeSolvedDialog;
	/**
	 * Alert dialog to store the all mazes solved dialog
	 */
	private final AlertDialog mAllMazesSolvedDialog;
	/**
	 * Boolean for the sensor enabled set to true
	 */
	private boolean mSensorEnabled = true;
	/**
	 * Instantiation of the AMazeDBAdapter class
	 */
	private AMazeDBAdapter mDB;
	/**
 *  
 */
	private final SensorListener mSensorAccelerometer = new SensorListener() {

		public void onSensorChanged(int sensor, float[] values) {
			if (!mSensorEnabled)
				return;

			mAccelX = values[0];
			mAccelY = values[1];

			mCommandedRollDirection = Direction.NONE;
			if (Math.abs(mAccelX) > Math.abs(mAccelY)) {
				if (mAccelX < -ACCEL_THRESHOLD)
					mCommandedRollDirection = Direction.LEFT;

				if (mAccelX > ACCEL_THRESHOLD)
					mCommandedRollDirection = Direction.RIGHT;
			} else {
				if (mAccelY < -ACCEL_THRESHOLD)
					mCommandedRollDirection = Direction.DOWN;

				if (mAccelY > ACCEL_THRESHOLD)
					mCommandedRollDirection = Direction.UP;
			}

			if (mCommandedRollDirection != Direction.NONE && !mBall.isRolling()) {
				rollBall(mCommandedRollDirection);
			}
		}

		public void onAccuracyChanged(int sensor, int accuracy) {
		}
	};

	@SuppressLint("HandlerLeak")
	public GameEngine(final Context context) {
		// Open maze database
		mDB = new AMazeDBAdapter(context).open();
		mCurrentMap = mDB.getFirstUnsolved();

		// Request vibrator service
		mVibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);

		// Register the sensor listener
		mSensorManager = (SensorManager) context
				.getSystemService(Context.SENSOR_SERVICE);
		mSensorManager.registerListener(mSensorAccelerometer,
				SensorManager.SENSOR_ACCELEROMETER,
				SensorManager.SENSOR_DELAY_GAME);

		mMap = new Map(MapDesigns.designList.get(mCurrentMap));

		// Create ball
		mBall = new Ball(this, mMap, mMap.getInitialPositionX(),
				mMap.getInitialPositionY());

		// Congratulations dialog
		mMazeSolvedDialog = new AlertDialog.Builder(context)
				.setCancelable(true)
				.setIcon(android.R.drawable.ic_dialog_info)
				.setTitle("Congratulations!")
				.setPositiveButton("Go to next maze!",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								dialog.cancel();
								sendEmptyMessage(Messages.MSG_MAP_NEXT);
							}
						}).create();

		// Final congratulations dialog
		mAllMazesSolvedDialog = new AlertDialog.Builder(context)
				.setCancelable(true)
				.setIcon(android.R.drawable.ic_dialog_alert)
				.setTitle("Congratulations!")
				.setPositiveButton("OK!",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								dialog.cancel();
								sendEmptyMessage(Messages.MSG_MAP_NEXT);
							}
						}).create();

		// Create message handler
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case Messages.MSG_INVALIDATE:
					mMazeView.invalidate();
					return;

				case Messages.MSG_REACHED_GOAL:
					mRemainingGoalsLabel.setText("" + mMap.getGoalCount());
					mRemainingGoalsLabel.invalidate();
					vibrate(100);
					if (mMap.getGoalCount() == 0) {
						AMazeActivity.isDone = true;
						mDB.updateMaze(mCurrentMap, mStepCount,
								AMazeActivity.TimeEnd);
						AMazeActivity.TimeCounter = 0;
						if (mDB.unsolvedMazes().getCount() == 0) {
							mAllMazesSolvedDialog
									.setMessage("Awesome!\nYou have solved all the mazes!\n"
											+ "Now go back and try to solve them in fewer steps or less time! :)");
							mAllMazesSolvedDialog.show();

							// If the user completed all challenges reset the
							// MediaPlayer
							AMazeActivity.mPlayer.reset();
							// Creates our win sound effect based on its URI
							AMazeActivity.mPlayer = MediaPlayer.create(context,
									R.raw.cheering);
							// starting the music playing
							AMazeActivity.mPlayer.start();
						} else {

							// If the user completed the next challenges reset
							// the MediaPlayer
							AMazeActivity.mPlayer.reset();
							AMazeActivity.mPlayer.reset();
							// Creates our win sound effect based on its URI
							AMazeActivity.mPlayer = MediaPlayer.create(context,
									R.raw.win);
							// starting the music playing
							AMazeActivity.mPlayer.start();
							mMazeSolvedDialog
									.setMessage("You have solved maze "
											+ mMap.getName() + " in "
											+ mStepCount + " steps.");
							mMazeSolvedDialog.show();
						}
					}
					return;

				case Messages.MSG_REACHED_WALL:
					vibrate(12);
					return;

				case Messages.MSG_RESTART:
					loadMap(mCurrentMap);
					return;

				case Messages.MSG_MAP_PREVIOUS:
				case Messages.MSG_MAP_NEXT:
					switch (msg.what) {
					case (Messages.MSG_MAP_PREVIOUS):
						if (mCurrentMap == 0) {
							// Wrap around
							mMapToLoad = MapDesigns.designList.size() - 1;
						} else {
							mMapToLoad = (mCurrentMap - 1)
									% MapDesigns.designList.size();
						}
						break;

					case (Messages.MSG_MAP_NEXT):
						mMapToLoad = (mCurrentMap + 1)
								% MapDesigns.designList.size();
						break;
					}

					loadMap(mMapToLoad);

					// Finding the name of the current map
					if (getMap().getName().equalsIgnoreCase("APPvengers")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackone);
						// starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					// Finding the name of the current map
					else if ((getMap().getName().equalsIgnoreCase("Iron Man"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}

						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.tracktwo);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("Captain A")) {

						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}

						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackthree);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					// Finding the name of the current map
					else if ((getMap().getName().equalsIgnoreCase("thor"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackfour);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("Hawkeye")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackfive);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					else if ((getMap().getName()
							.equalsIgnoreCase("Black Widow"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.tracksix);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("The Hulk")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackseven);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					// Finding the name of the current map
					else if ((getMap().getName().equalsIgnoreCase("Loki"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackeight);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("Nick Fury")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.tracknine);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if ((getMap().getName().equalsIgnoreCase("Thanos"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackten);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("Ultron")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackeleven);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					// Finding the name of the current map
					else if ((getMap().getName()
							.equalsIgnoreCase("Scarlett Witch"))) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.tracktwelve);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);

					}

					// Finding the name of the current map
					else if (getMap().getName().equalsIgnoreCase("Quicksilver")) {

						// Ensures no overlap of mPlayer Media Player object.
						if (AMazeActivity.mPlayer.isPlaying()) {
							AMazeActivity.mPlayer.stop();
						}
						// Creates the song with correct URI
						AMazeActivity.mPlayer = MediaPlayer.create(context,
								R.raw.trackthirteen);
						// Starting the music playing
						AMazeActivity.mPlayer.start();
						// Enabling loop of music to avoid audio loss and in
						// game silence
						AMazeActivity.mPlayer.setLooping(true);
					}

					return;
				}

				super.handleMessage(msg);
			}
		};
	}

	/**
	 * Method to load the map
	 * 
	 * @param mapID
	 */
	public void loadMap(int mapID) {
		AMazeActivity.resetTimer();

		mCurrentMap = mapID;
		mBall.stop();
		mMap = new Map(MapDesigns.designList.get(mCurrentMap));
		mBall.setMap(mMap);
		mBall.setX(mMap.getInitialPositionX());
		mBall.setY(mMap.getInitialPositionY());
		mBall.setXTarget(mMap.getInitialPositionX());
		mBall.setYTarget(mMap.getInitialPositionY());
		mMap.init();

		mStepCount = 0;

		mMazeNameLabel.setText(mMap.getName());
		mMazeNameLabel.invalidate();

		mRemainingGoalsLabel.setText("" + mMap.getGoalCount());
		mRemainingGoalsLabel.invalidate();

		mStepsView.setText("" + mStepCount);
		mStepsView.invalidate();

		mMazeView.calculateUnit();
		mMazeView.invalidate();
	}

	/**
	 * Method to set maze name label
	 * 
	 * @param mazeNameLabel
	 */
	public void setMazeNameLabel(TextView mazeNameLabel) {
		mMazeNameLabel = mazeNameLabel;
	}

	/**
	 * Method to set remaining goals label
	 * 
	 * @param remainingGoalsLabel
	 */
	public void setRemainingGoalsLabel(TextView remainingGoalsLabel) {
		mRemainingGoalsLabel = remainingGoalsLabel;
	}

	/**
	 * Method to set maze view
	 * 
	 * @param mazeView
	 */
	public void setAMazeView(MazeView mazeView) {
		mMazeView = mazeView;
		mBall.setMazeView(mazeView);
	}

	/**
	 * Method to set the steps label
	 * 
	 * @param stepsView
	 */
	public void setStepsLabel(TextView stepsView) {
		mStepsView = stepsView;
	}

	/**
	 * Method to send empty message
	 * 
	 * @param msg
	 */
	public void sendEmptyMessage(int msg) {
		mHandler.sendEmptyMessage(msg);
	}

	/**
	 * Method to send message
	 * 
	 * @param msg
	 */
	public void sendMessage(Message msg) {
		mHandler.sendMessage(msg);
	}

	/**
	 * Method to register listener
	 */
	public void registerListener() {
		mSensorManager.registerListener(mSensorAccelerometer,
				SensorManager.SENSOR_ACCELEROMETER,
				SensorManager.SENSOR_DELAY_GAME);
	}

	/**
	 * Method to unregister listener
	 */
	public void unregisterListener() {
		mSensorManager.unregisterListener(mSensorAccelerometer);
	}

	/**
	 * Method for ball roll
	 * 
	 * @param dir
	 */
	public void rollBall(Direction dir) {
		// If the ball rolls the step count is incremented
		if (mBall.roll(dir))
			mStepCount++;
		mStepsView.setText("" + mStepCount);
		mStepsView.invalidate();
	}

	/**
	 * Method to get the ball
	 * 
	 * @return
	 */
	public Ball getBall() {
		return mBall;
	}

	/**
	 * Method to get the map
	 * 
	 * @return
	 */
	public Map getMap() {
		return mMap;
	}

	/**
	 * Method to enable the sensor
	 * 
	 * @return
	 */
	public boolean isSensorEnabled() {
		return mSensorEnabled;
	}

	/**
	 * Method to toggle the sensor
	 */
	public void toggleSensorEnabled() {
		mSensorEnabled = !mSensorEnabled;
	}

	/**
	 * Vibrate method
	 * 
	 * @param milliseconds
	 */
	public void vibrate(long milliseconds) {
		mVibrator.vibrate(milliseconds);
	}

	/**
	 * Save state method
	 * 
	 * @param icicle
	 */
	public void saveState(Bundle icicle) {
		mBall.stop();

		icicle.putInt("map.id", mCurrentMap);

		int[][] goals = mMap.getGoals();
		int sizeX = mMap.getSizeX();
		int sizeY = mMap.getSizeY();
		int[] goalsToSave = new int[sizeX * sizeY];
		for (int y = 0; y < sizeY; y++)
			for (int x = 0; x < sizeX; x++)
				goalsToSave[y + x * sizeX] = goals[y][x];
		icicle.putIntArray("map.goals", goalsToSave);

		icicle.putInt("stepcount", mStepCount);

		icicle.putInt("ball.x", Math.round(mBall.getX()));
		icicle.putInt("ball.y", Math.round(mBall.getY()));
	}

	/**
	 * Restore state method
	 * 
	 * @param icicle
	 * @param sensorEnabled
	 */
	public void restoreState(Bundle icicle, boolean sensorEnabled) {
		if (icicle != null) {
			int mapID = icicle.getInt("map.id", -1);
			if (mapID == -1)
				return;
			loadMap(mapID);

			int[] goals = icicle.getIntArray("map.goals");
			if (goals == null)
				return;

			int sizeX = mMap.getSizeX();
			int sizeY = mMap.getSizeY();
			for (int y = 0; y < sizeY; y++)
				for (int x = 0; x < sizeX; x++)
					mMap.setGoal(x, y, goals[y + x * sizeX]);

			mBall.setX(icicle.getInt("ball.x"));
			mBall.setY(icicle.getInt("ball.y"));

			// We have probably moved the ball, so invalidate the Maze View
			mMazeView.invalidate();

			mStepCount = icicle.getInt("stepcount", 0);
		}
		mRemainingGoalsLabel.setText("" + mMap.getGoalCount());
		mRemainingGoalsLabel.invalidate();

		mStepsView.setText("" + mStepCount);
		mStepsView.invalidate();

		mSensorEnabled = sensorEnabled;
	}
}
