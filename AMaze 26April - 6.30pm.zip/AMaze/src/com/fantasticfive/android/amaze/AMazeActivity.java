package com.fantasticfive.android.amaze;

// imports
import java.util.Timer;
import java.util.TimerTask;
import com.fantasticfive.android.amaze.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

/**
 * 
 * @author The Appvengers
 * 
 */
public class AMazeActivity extends Activity {
	protected PowerManager.WakeLock mWakeLock;
	/**
	 * Instantiation of the MazeView class
	 */
	private MazeView mMazeView;
	/**
	 * Constants to store menu options
	 */
	private static final int MENU_RESTART = 1;
	private static final int MENU_MAP_PREV = 2;
	private static final int MENU_MAP_NEXT = 3;
	private static final int MENU_SENSOR = 4;
	private static final int MENU_SELECT_MAZE = 5;
	private static final int MENU_ABOUT = 6;

	private static final int REQUEST_SELECT_MAZE = 1;
	public static boolean ifPaused = false;
	public static boolean isDone = false;
	public static int TimeCounter = 0;
	public static int TimeEnd = 0;
	private static boolean timerNotified = false;
	private TextView mTimer;
	private Timer t;

	private Dialog mAboutDialog;

	private Intent mSelectMazeIntent;

	private TextView mMazeNameLabel;
	private TextView mRemainingGoalsLabel;
	private TextView mStepsLabel;

	private GestureDetector mGestureDetector;
	private GameEngine mGameEngine;

	public static MediaPlayer mPlayer;
	private boolean doubleBackToExitPressedOnce;

	public static MediaPlayer effectsPlayer;

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// As soon as game started or reloaded appropriate track will be created
		// and played.
		requestAudioFocus();

		final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "aMaze");

		mSelectMazeIntent = new Intent(AMazeActivity.this,
				SelectMazeActivity.class);

		// Build the About Dialog
		mAboutDialog = new Dialog(AMazeActivity.this);
		mAboutDialog.setCancelable(true);
		mAboutDialog.setCanceledOnTouchOutside(true);
		mAboutDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mAboutDialog.setContentView(R.layout.about_layout);

		Button aboutDialogOkButton = (Button) mAboutDialog
				.findViewById(R.id.about_ok_button);
		aboutDialogOkButton.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				mAboutDialog.cancel();
			}
		});

		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.game_layout);
		LinearLayout li = (LinearLayout) findViewById(R.id.myscreen);
		li.setBackgroundColor(Color.rgb(0, 0, 0));

		// Show the About Dialog on the first start
		if (getPreferences(MODE_PRIVATE).getBoolean("firststart", true)) {
			getPreferences(MODE_PRIVATE).edit().putBoolean("firststart", false)
					.commit();
			mAboutDialog.show();
		}

		// Set up game engine and connect it with the relevant views
		mGameEngine = new GameEngine(AMazeActivity.this);
		mMazeView = (MazeView) findViewById(R.id.maze_view);
		mGameEngine.setAMazeView(mMazeView);
		mMazeView.setGameEngine(mGameEngine);
		mMazeView.calculateUnit();

		mMazeNameLabel = (TextView) findViewById(R.id.maze_name);
		mGameEngine.setMazeNameLabel(mMazeNameLabel);
		mMazeNameLabel.setText(mGameEngine.getMap().getName());

		mMazeNameLabel.invalidate();

		mRemainingGoalsLabel = (TextView) findViewById(R.id.remaining_goals);
		mGameEngine.setRemainingGoalsLabel(mRemainingGoalsLabel);

		mStepsLabel = (TextView) findViewById(R.id.steps);
		mGameEngine.setStepsLabel(mStepsLabel);

		mTimer = (TextView) findViewById(R.id.timer);
		mStepsLabel = (TextView) findViewById(R.id.steps);
		mGameEngine.setStepsLabel(mStepsLabel);

		mGameEngine.restoreState(savedInstanceState,
				getPreferences(MODE_PRIVATE).getBoolean("sensorenabled", true));

		// Create gesture detector to detect flings
		mGestureDetector = new GestureDetector(
				new GestureDetector.SimpleOnGestureListener() {
					@Override
					public boolean onDown(MotionEvent e) {
						return true;
					}

					@Override
					public boolean onFling(MotionEvent e1, MotionEvent e2,
							float velocityX, float velocityY) {
						// Roll the ball in the direction of the fling
						Direction mCommandedRollDirection = Direction.NONE;

						if (Math.abs(velocityX) > Math.abs(velocityY)) {
							if (velocityX < 0)
								mCommandedRollDirection = Direction.LEFT;
							else
								mCommandedRollDirection = Direction.RIGHT;
						} else {
							if (velocityY < 0)
								mCommandedRollDirection = Direction.UP;
							else
								mCommandedRollDirection = Direction.DOWN;
						}

						if (mCommandedRollDirection != Direction.NONE) {
							mGameEngine.rollBall(mCommandedRollDirection);
						}

						return true;
					}
				});
		mGestureDetector.setIsLongpressEnabled(false);
		startTimer();
	}

	// private int Color(int rgb) {
	// return 0;
	// }

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return mGestureDetector.onTouchEvent(event);
	}

	/**
	 * Method to create menu
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		menu.add(0, MENU_MAP_PREV, 0, R.string.menu_map_prev);
		menu.add(0, MENU_RESTART, 0, R.string.menu_restart);
		menu.add(0, MENU_MAP_NEXT, 0, R.string.menu_map_next);
		menu.add(0, MENU_SENSOR, 0, R.string.menu_sensor);
		menu.add(0, MENU_SELECT_MAZE, 0, R.string.menu_select_maze);
		menu.add(0, MENU_ABOUT, 0, R.string.menu_about);

		menu.findItem(MENU_MAP_PREV).setIcon(
				getResources()
						.getDrawable(android.R.drawable.ic_media_previous));
		menu.findItem(MENU_RESTART).setIcon(
				getResources().getDrawable(android.R.drawable.ic_menu_rotate));
		menu.findItem(MENU_MAP_NEXT).setIcon(
				getResources().getDrawable(android.R.drawable.ic_media_next));
		menu.findItem(MENU_SENSOR)
				.setIcon(
						getResources()
								.getDrawable(
										mGameEngine.isSensorEnabled() ? android.R.drawable.button_onoff_indicator_on
												: android.R.drawable.button_onoff_indicator_off));
		menu.findItem(MENU_SELECT_MAZE).setIcon(
				getResources().getDrawable(android.R.drawable.ic_menu_more));
		menu.findItem(MENU_ABOUT).setIcon(
				getResources().getDrawable(
						android.R.drawable.ic_menu_info_details));
		return true;
	}

	/**
	 * Method for options selected in menu
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case MENU_RESTART:
			// Menu sound effect playback to confirm user has selected an option
			swoosh();
			mGameEngine.sendEmptyMessage(Messages.MSG_RESTART);
			assignAudioTrack();
			return true;
		case MENU_MAP_PREV:
			mGameEngine.sendEmptyMessage(Messages.MSG_MAP_PREVIOUS);
			// Menu sound effect playback to confirm user has selected the
			// previous map
			swoosh();
			assignAudioTrack();
			return true;
		case MENU_MAP_NEXT:
			mGameEngine.sendEmptyMessage(Messages.MSG_MAP_NEXT);
			// Menu sound effect playback to confirm user has selected the next
			// map.
			swoosh();
			assignAudioTrack();
			return true;
		case MENU_SENSOR:
			mGameEngine.toggleSensorEnabled();
			// Menu sound effect playback to confirm user has toggled the
			// sensor.
			swoosh();
			item.setIcon(getResources()
					.getDrawable(
							mGameEngine.isSensorEnabled() ? android.R.drawable.button_onoff_indicator_on
									: android.R.drawable.button_onoff_indicator_off));
			getPreferences(MODE_PRIVATE).edit()
					.putBoolean("sensorenabled", mGameEngine.isSensorEnabled())
					.commit();
			return true;
		case MENU_SELECT_MAZE:
			// Menu sound effect playback to confirm user has selected a new
			// maze
			swoosh();
			startActivityForResult(mSelectMazeIntent, REQUEST_SELECT_MAZE);
			return true;
		case MENU_ABOUT:
			// Menu sound effect playback to confirm user has selected About
			// page
			swoosh();
			mAboutDialog.show();
			return true;
		}

		return false;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode) {
		case (REQUEST_SELECT_MAZE):
			if (resultCode == Activity.RESULT_OK) {
				int selectedMaze = data.getIntExtra("selected_maze", 0);
				mGameEngine.loadMap(selectedMaze);
			}
			break;
		}
	}

	/**
	 * Method that assigns the audio track to applicable maze level. Maze levels
	 * 1-13, depending on the map name the correct audio file will be played
	 */
	private void assignAudioTrack() {

		// Finding the name of the current map
		if (mGameEngine.getMap().getName().equalsIgnoreCase("APPvengers")) {

			// Ensures no overlap of mPlayer Media Player object.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackone);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);
		}

		else if ((mGameEngine.getMap().getName().equalsIgnoreCase("Iron Man"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.tracktwo);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("Captain A")) {

			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackthree);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);
		}

		else if ((mGameEngine.getMap().getName().equalsIgnoreCase("thor"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackfour);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("Hawkeye")) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackfive);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if ((mGameEngine.getMap().getName()
				.equalsIgnoreCase("Black Widow"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.tracksix);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("The Hulk")) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackseven);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);
		}

		else if ((mGameEngine.getMap().getName().equalsIgnoreCase("Loki"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackeight);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("Nick Fury")) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.tracknine);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if ((mGameEngine.getMap().getName().equalsIgnoreCase("Thanos"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackten);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("Ultron")) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.trackeleven);
			// Starting the music playing
			mPlayer.start();

			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);
		}

		else if ((mGameEngine.getMap().getName()
				.equalsIgnoreCase("Scarlett Witch"))) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.tracktwelve);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);

		}

		else if (mGameEngine.getMap().getName().equalsIgnoreCase("Quicksilver")) {

			// Ensures no overlap of mPlayer Media Player.
			if (mPlayer.isPlaying()) {
				mPlayer.stop();
			}
			// Creates the song with correct URI
			mPlayer = MediaPlayer.create(AMazeActivity.this,
					R.raw.trackthirteen);
			// Starting the music playing
			mPlayer.start();
			// Enabling loop of music to avoid audio loss and in game silence
			mPlayer.setLooping(true);
		}

	}

	/**
	 * Method to provide 'swoosh' menu sound using another instance of Media
	 * Player
	 */
	public void swoosh() {

		// Creates the sound and find the uri location.
		effectsPlayer = MediaPlayer.create(AMazeActivity.this, R.raw.swoosh);

		// Start the object playing.
		effectsPlayer.start();

	}

	/**
	 * Method to request Audio Focus and ensure that only one activity is
	 * playing its sound at a time.
	 */
	public void requestAudioFocus() {

		// Call to system audio service
		AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

		// Setting up of handler to enable audio focus changes
		OnAudioFocusChangeListener afChangeListener = new OnAudioFocusChangeListener() {
			public void onAudioFocusChange(int focusChange) {

				// Allows ducking if interrupted
				if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
					mPlayer.pause();
				}
				// Allows the audio to start once focus has been gained
				else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
					mPlayer.start();
				}

				// Allows the audio to pause if focus has been interupted
				else if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
					mPlayer.pause();
					;
				}
			}
		};

		// Request audio focus for playback
		int result = am.requestAudioFocus(afChangeListener,
		// Use the music stream.
				AudioManager.STREAM_MUSIC,
				// Request permanent focus.
				AudioManager.AUDIOFOCUS_GAIN);

		// If we gain Audio Focus from system instantiate a new Media Player.
		if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
			mPlayer = new MediaPlayer();
		}

	}

	/**
	 * Method providing double button back press functionality and utilises
	 * toast class to display prompts to user.
	 */
	@Override
	public void onBackPressed() {

		// Allows second input of back button to exit
		if (doubleBackToExitPressedOnce) {
			super.onBackPressed();
			return;
		}

		// Registering if back button has been selected for the first time
		this.doubleBackToExitPressedOnce = true;
		// displaying Toast message to the user
		Toast.makeText(getBaseContext(), "Click back again to exit..",
				Toast.LENGTH_SHORT).show();

	}

	/**
	 * Method that starts after onCreate() will reload audio based on
	 * appropriate level user has completed.
	 */
	@Override
	protected void onStart() {
		super.onStart();
		// Once activity is created or resumed the audio will resume in the
		// correct place
		assignAudioTrack();
	}

	@Override
	protected void onPause() {
		super.onPause();
		mPlayer.pause();
	}

	//
	@Override
	protected void onResume() {
		super.onResume();
		// Should the user navigate from and back to activity will resume audio
		// playback
		mPlayer.start();
	}

	/**
	 * On stop method
	 */
	@Override
	protected void onStop() {
		// Allows for pause of audio should user navigate away from activity
		if (mPlayer.isPlaying()) {
			mPlayer.pause();
		}
		super.onStop();
	}

	/**
	 * On restore method
	 */
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		mGameEngine.restoreState(savedInstanceState,
				getPreferences(MODE_PRIVATE).getBoolean("sensorenabled", true));
	}

	/**
	 * On destroy method
	 */
	@Override
	protected void onDestroy() {
		mPlayer.stop();
		mPlayer.release();
		super.onDestroy();
	}

	/**
	 * Method to start the timer which updates every 1000 milliseconds
	 */
	public void startTimer() {
		t = new Timer();
		t.scheduleAtFixedRate(new TimerTask() {

			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					public void run() {
						// If the maze is still in progress update the displayed
						// time, increase the time counter and continue
						if (!isDone) {
							mTimer = (TextView) findViewById(R.id.timer);
							mTimer.setText(String.valueOf("Time: "
									+ TimeCounter));
							TimeCounter++;
							// If the maze is completed, notify the user
						} else {
							if (!timerNotified) {
								notifyUser();
							}
						}
						TimeEnd = TimeCounter;
					}
				});
			}
		}, 1000, 1000);

	}

	/**
	 * Method to display a toast for the time when maze is completed
	 */
	public void notifyUser() {
		Toast.makeText(this,
				"The time taken is " + String.valueOf(TimeEnd) + "s",
				Toast.LENGTH_LONG).show();
		timerNotified = true;
	}

	/**
	 * Method to reset the timer
	 */
	public static void resetTimer() {
		isDone = false;
		timerNotified = false;
		TimeCounter = 0;
		TimeEnd = 0;
	}
}