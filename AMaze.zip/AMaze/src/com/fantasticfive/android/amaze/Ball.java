package com.fantasticfive.android.amaze;

// imports
import java.util.Timer;
import java.util.TimerTask;
import android.os.SystemClock;

/**
 * 
 * @author FantasticFive
 *
 */
public class Ball {
	
	// instantiation of the GameEngine class
	private GameEngine mEngine;
	// instantiation of the map class
	private Map mMap;
	// instantiation of the MazeView class
	private MazeView mMazeView;

	// Current position
	// first set the x to 0
	private float mX = 0;
	// and then the y axis to 0
	private float mY = 0;

	// Target positions for goal
	private int mXTarget;
	private int mYTarget;

	// Speed at which the ball will move when tilt or touch is initiated
	private int mVX = 0; // -1, 0 or 1
	private int mVY = 0; // -1, 0 or 1

	// On-screen speed
	private static float SPEED_MULTIPLIER = 0.005f;

	// Time
	private long mT1;
	private long mT2;
	private static final int DT_TARGET = 1000 / 25; // Target time step (ms)

	// Timer to schedule simulation steps
	private Timer mTimer;

	// boolean which will check if the ball is already rolling
	private boolean mIsRolling = false;

	// instantiation of the direction class which is initially set to no
	// movement
	private Direction mRollDirection = Direction.NONE;

	/**
	 * Main ball method - constructor with arguments
	 * 
	 * @param engine
	 * @param map
	 * @param init_x
	 * @param init_y
	 */
	public Ball(GameEngine engine, Map map, int init_x, int init_y) {

		// assigns the taken in parameters to the variables used in the class
		mEngine = engine;
		mMap = map;
		mX = init_x;
		mY = init_y;
		mXTarget = init_x;
		mYTarget = init_y;
	}

	// setters and getters
	public Direction getRollDirection() {
		return mRollDirection;
	}
	public float getX() {
		return mX;
	}
	public float getY() {
		return mY;
	}
	public void setX(float x) {
		mX = x;
	}
	public void setY(float y) {
		mY = y;
	}
	public void setXTarget(int x) {
		mXTarget = x;
	}
	public void setYTarget(int y) {
		mYTarget = y;
	}
	public float getXTarget() {
		return mXTarget;
	}
	public float getYTarget() {
		return mYTarget;
	}

	/**
	 * Method to set the mazeView
	 * 
	 * @param mazeView
	 */
	public void setMazeView(MazeView mazeView) {
		mMazeView = mazeView;
	}

	/**
	 * setting the map
	 * 
	 * @param map
	 */
	public void setMap(Map map) {
		mMap = map;
	}

	/**
	 * getter for the isRolling variable
	 * 
	 * @return
	 */
	public boolean isRolling() {
		return mIsRolling;
	}

	/**
	 * private method which will check if the move the user is trying to make is
	 * valid
	 * 
	 * @param x
	 * @param y
	 * @param dir
	 * @return
	 */
	@SuppressWarnings("incomplete-switch")
	private boolean isValidMove(int x, int y, Direction dir) {

		// switch statement based on the direction which has been passed into
		// the method, which is an ENUM
		switch (dir) {

		// if the passed in ENUM is left
		case LEFT:

			// if the ball is placed on the x-axis at 0 or less then the move is
			// invalid as the ball can not move left
			if (x <= 0)
				return false;

			// this checks if there is a wall blocking the movement of the ball
			// but, not the outer wall of the maze
			if ((mMap.getWalls(x, y) & Wall.LEFT) > 0
					|| (mMap.getWalls(x - 1, y) & Wall.RIGHT) > 0)
				return false;
			break;

		// if the passed in ENUM is right
		case RIGHT:

			// if the ball is placed on the axis at greater than or less than
			// the size of the x axis of the map -1 then the move is
			// invalid as the ball can not move right
			if (x >= mMap.getSizeX() - 1)
				return false;

			// this checks if there is a wall blocking the movement of the ball
			// but, not the outer wall of the maze
			if ((mMap.getWalls(x, y) & Wall.RIGHT) > 0
					|| (mMap.getWalls(x + 1, y) & Wall.LEFT) > 0)
				return false;
			break;

		// if the passed in ENUM is up
		case UP:

			// if the ball is placed on the y-axis at 0 or less then the move is
			// invalid as the ball can not move up further
			if (y <= 0)
				return false;

			// this checks if there is a wall blocking the movement of the ball
			// not the outer wall of the maze
			if ((mMap.getWalls(x, y) & Wall.TOP) > 0
					|| (mMap.getWalls(x, y - 1) & Wall.BOTTOM) > 0)
				return false;
			break;

		// if the passed in ENUM is down
		case DOWN:

			// if the ball is placed on the y-axis at greater than or less than
			// the size of the y-axis of the map -1 then the move is
			// invalid as the ball can not move down
			if (y >= mMap.getSizeY() - 1)
				return false;

			// this checks if there is a wall blocking the movement of the ball
			// but, not the outer wall of the maze
			if ((mMap.getWalls(x, y) & Wall.BOTTOM) > 0
					|| (mMap.getWalls(x, y + 1) & Wall.TOP) > 0)
				return false;
			break;
		}

		// if these conditions are not met then return true as the move must be
		// valid
		return true;
	}

	/**
	 * Method which uses much the same as the code to make sure transactions
	 * happen concurrently this method will make sure that two calls to move the
	 * ball can not be made at the same time and must happen only once one has
	 * finished
	 * 
	 * @param dir
	 * @return
	 */
	@SuppressWarnings("incomplete-switch")
	public synchronized boolean roll(Direction dir) {

		// Don't accept another roll command if the ball is already rolling
		if (mIsRolling)
			return false;

		// Set speed according to commanded direction

		// switch statement based on the passed in direction

		switch (dir) {
		// passed in ENUM is left
		case LEFT: {
			// roll down the x axis -1
			mVX = -1;
			// do not roll down the y axis at all
			mVY = 0;
			break;
		}
		// passed in ENUM is right
		case RIGHT: {
			// roll down the x axis +1
			mVX = 1;
			// do not roll down the y axis at all
			mVY = 0;
			break;
		}
		// passed in ENUM is up
		case UP: {
			// do not roll down the x axis at all
			mVX = 0;
			// roll -1 down the y axis
			mVY = -1;
			break;
		}
		// passed in ENUM is down
		case DOWN: {
			// do not go down the x axis at all
			mVX = 0;
			// roll down the y axis 1
			mVY = 1;
			break;
		}
		}

		// Calculate target position using math.round to get an INT
		mXTarget = Math.round(mX);
		mYTarget = Math.round(mY);

		// while the move is valid pass in the rounded x and y targets and carry
		// out until false
		while (isValidMove(mXTarget, mYTarget, dir)) {
			mXTarget = mXTarget + mVX;
			mYTarget = mYTarget + mVY;
		}

		// We can't move if the x and y target = the x and y axis speed return
		// the boolean as false
		if (mXTarget == mX && mYTarget == mY)
			return false;

		// Let's roll...
		mIsRolling = true;
		mRollDirection = dir;

		// Schedule animation
		mT1 = SystemClock.elapsedRealtime();
		TimerTask simTask = new TimerTask() {
			public void run() {
				doStep();
			}
		};
		mTimer = new Timer(true);
		mTimer.schedule(simTask, 0, DT_TARGET);

		return true;
	}

	/**
	 * Method to be called when the ball needs to stop
	 */
	public void stop() {

		// if the ball is not rolling
		if (!mIsRolling)
			return;

		// cancel the animation
		mTimer.cancel();
		// set the rolling to false
		mIsRolling = false;
		// set x axis to target
		mX = mXTarget;
		// set y axis to target
		mY = mYTarget;
		// use the MazeView variable to calculate postInvalidate method in the
		// mazeView
		// class
		mMazeView.postInvalidate();
	}

	/**
	 * doStep method
	 */
	@SuppressWarnings("incomplete-switch")
	private void doStep() {

		// Calculate elapsed time since last step
		mT2 = SystemClock.elapsedRealtime();
		float dt = (float) (mT2 - mT1);
		mT1 = mT2;

		// Calculate next position
		float xNext = mX + mVX * SPEED_MULTIPLIER * dt;
		float yNext = mY + mVY * SPEED_MULTIPLIER * dt;

		// Check if we have reached the target position
		boolean reachedTarget = false;

		// switch on roll direction
		switch (mRollDirection) {

		// if ball moving left
		case LEFT:
			if (xNext <= 1f * mXTarget) {
				xNext = mXTarget;
				reachedTarget = true;
			}
			break;

		// if ball moving right
		case RIGHT:
			if (xNext >= 1f * mXTarget) {
				xNext = mXTarget;
				reachedTarget = true;
			}
			break;

		// if ball moving up
		case UP:
			if (yNext <= 1f * mYTarget) {
				yNext = mYTarget;
				reachedTarget = true;
			}
			break;

		// if ball moving down
		case DOWN:
			if (yNext > 1f * mYTarget) {
				yNext = mYTarget;
				reachedTarget = true;
			}
			break;
		}

		mX = xNext;
		mY = yNext;

		// Check if we have reached a goal
		if (mMap.getGoal(Math.round(mX), Math.round(mY)) == 1) {

			// remove the goal from the map
			mMap.removeGoal(Math.round(mX), Math.round(mY));

			// display message to user that they have reached the goal
			mEngine.sendEmptyMessage(Messages.MSG_REACHED_GOAL);
		}

		// Stop rolling if we have reached the target position
		if (reachedTarget) {
			mRollDirection = Direction.NONE;
			mVX = 0;
			mVY = 0;
			mIsRolling = false;
			mTimer.cancel();

			// Send MSG_REACHED_WALL message to the parent View
			mEngine.sendEmptyMessage(Messages.MSG_REACHED_WALL);
		}

		// Send invalidate message to the parent View,
		// so that it gets redrawn during the next cycle.
		mMazeView.postInvalidate();
	}
}