package com.fantasticfive.android.amaze;

/**
 * Map design class
 * 
 * @author FantasticFive
 * 
 */
public class MapDesign {

	// declaring private variables
	private String mName;
	private int mSizeX = 0;
	private int mSizeY = 0;
	private int[][] mWalls;
	private int[][] mGoals;
	private int mInitialPositionX;
	private int mInitialPositionY;
	private int mGoalCount = 0;
	private int mRed = 0;
	private int mGreen = 0;
	private int mBlue = 0;

	/**
	 * Constructor with arguments
	 * 
	 * @param name
	 * @param sizeX
	 * @param sizeY
	 * @param walls
	 * @param goals
	 * @param initialPositionX
	 * @param initialPositionY
	 */
	public MapDesign(String name, int sizeX, int sizeY, int[][] walls,
			int[][] goals, int initialPositionX, int initialPositionY, int red,
			int blue, int green) {
		mName = name;
		mSizeX = sizeX;
		mSizeY = sizeY;
		mWalls = walls;
		mGoals = goals;
		mRed = red;
		mGreen = green;
		mBlue = blue;
		mInitialPositionX = initialPositionX;
		mInitialPositionY = initialPositionY;
		for (int y = 0; y < mSizeY; y++) {
			for (int x = 0; x < mSizeX; x++) {
				mGoalCount = mGoalCount + mGoals[y][x];
			}
		}
	}

	public String getName() {
		return mName;
	}

	public int[][] getWalls() {
		return mWalls;
	}

	public int getWalls(int x, int y) {
		return mWalls[y][x];
	}

	public int[][] getGoals() {
		return mGoals;
	}

	public int getGoalCount() {
		return mGoalCount;
	}

	public int getSizeX() {
		return mSizeX;
	}

	public int getSizeY() {
		return mSizeY;
	}

	public int getInitialPositionX() {
		return mInitialPositionX;
	}

	public int getInitialPositionY() {
		return mInitialPositionY;
	}

	// to allow red conponent of RGB colour to be set for background - this and
	// blue and green where implemented before we decided to use a background
	// image
	public int getRed() {
		return mRed;
	}

	public int getGreen() {
		return mGreen;
	}

	public int getBlue() {
		return mBlue;
	}
}
