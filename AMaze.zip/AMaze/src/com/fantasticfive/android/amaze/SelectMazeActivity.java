package com.fantasticfive.android.amaze;

// imports
import com.fantasticfive.android.amaze.R;
import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

/**
 * 
 * @author FantasticFive
 * 
 */
public class SelectMazeActivity extends ListActivity {
	private AMazeDBAdapter mDB;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mDB = new AMazeDBAdapter(getApplicationContext()).open();

		setListAdapter(new CursorAdapter(getApplicationContext(),
				mDB.allMazes(), true) {

			@Override
			public View newView(Context context, Cursor cursor, ViewGroup parent) {
				final LayoutInflater inflater = LayoutInflater.from(context);
				final View rowView = inflater.inflate(
						R.layout.select_maze_row_layout, parent, false);

				bindView(rowView, context, cursor);
				return rowView;
			}

			@Override
			public void bindView(View view, Context context, Cursor cursor) {
				final MapDesign m = MapDesigns.designList.get(cursor
						.getPosition());

				final ImageView mazeSolvedTickbox = (ImageView) view
						.findViewById(R.id.maze_solved_tick);
				final TextView mazeName = (TextView) view
						.findViewById(R.id.maze_name);
				final TextView mazeSolutionSteps = (TextView) view
						.findViewById(R.id.maze_solution_steps);

				mazeName.setText(cursor.getString(AMazeDBAdapter.NAME_COLUMN)
						+ " (" + m.getSizeX() + "x" + m.getSizeY() + "), "
						+ m.getGoalCount() + " goal"
						+ (m.getGoalCount() > 1 ? "s" : ""));

				if (cursor.getInt(AMazeDBAdapter.SOLUTION_STEPS_COLUMN) == 0) {
					mazeSolvedTickbox
							.setImageResource(android.R.drawable.checkbox_off_background);
					mazeSolutionSteps.setText("");
				} else {
					mazeSolvedTickbox
							.setImageResource(android.R.drawable.checkbox_on_background);
					mazeSolutionSteps
							.setText("Solved in "
									+ cursor.getString(AMazeDBAdapter.SOLUTION_STEPS_COLUMN)
									+ " steps and "
									+ cursor.getString(AMazeDBAdapter.TIME_TAKEN_COLUMN) + " seconds");
				}				
			}
		});
		setTitle(R.string.select_maze_title);
		setContentView(R.layout.select_maze_layout);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Intent result = new Intent();
		result.putExtra("selected_maze", position);
		setResult(RESULT_OK, result);
		finish();
	}
}
