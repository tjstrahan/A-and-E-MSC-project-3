package com.fantasticfive.android.amaze;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

/**
 * 
 * @author FantasticFive
 * 
 */
public class AMazeDBAdapter {

	// declaring static Strings for names
	private static final String DATABASE_NAME = "amaze.db";
	private static final String DATABASE_TABLE = "mazes";
	private static final int DATABASE_VERSION = 5;

	// declaring static Strings for the id key and column id
	public static final String KEY_ID = "_id";
	public static final int ID_COLUMN = 0;

	// declaring static String for the name of the key and the name of the
	// column
	public static final String KEY_NAME = "name";
	public static final int NAME_COLUMN = 1;

	// declaring the static string for the solution steps and the solution steps
	// column
	public static final String KEY_SOLUTION_STEPS = "solution_steps";
	public static final int SOLUTION_STEPS_COLUMN = 2;

	public static final String KEY_TIME_TAKEN = "time";
	public static final int TIME_TAKEN_COLUMN = 3;


	// declaring the string array for columns with the key id, key name and key
	// solution steps
	public static final String[] COLUMNS = { KEY_ID, KEY_NAME,
			KEY_SOLUTION_STEPS, KEY_TIME_TAKEN };

	// instantiation of SQLiteDatabase
	private SQLiteDatabase mDataBase;
	// instantiation of the AmazeDBOpenHelper
	private AMazeDBOpenHelper mDataBaseHelper;

	/**
	 * Constructor with arg
	 * 
	 * @param context
	 */
	public AMazeDBAdapter(Context context) {
		mDataBaseHelper = new AMazeDBOpenHelper(context, DATABASE_NAME, null,
				DATABASE_VERSION);
	}

	/**
	 * open the database adapter which will throw an SQLException if need be
	 * 
	 * @return
	 * @throws SQLException
	 */
	public AMazeDBAdapter open() throws SQLException {
		mDataBase = mDataBaseHelper.getWritableDatabase();
		return this;
	}

	/**
	 * close the database
	 */
	public void close() {
		mDataBase.close();
	}

	// Update "solution steps" column (only if it's 0 or the new value is less
	// then the current)
	public void updateMaze(int id, int solution_steps, int time) {
		ContentValues values = new ContentValues();
		values.put(KEY_SOLUTION_STEPS, solution_steps);
		values.put(KEY_TIME_TAKEN, time);

		mDataBase.update(DATABASE_TABLE, values, KEY_ID + " = ? AND ("
				+ KEY_SOLUTION_STEPS + " = ? OR " + KEY_SOLUTION_STEPS
				+ " > ?)", new String[] { "" + id, "0", "" + solution_steps });

		mDataBase.update(DATABASE_TABLE, values, KEY_ID + " = ? AND ("
				+ KEY_TIME_TAKEN + " = ? OR " + KEY_TIME_TAKEN + " > ?)",
				new String[] { "" + id, "0", "" + time });
	}

	public Cursor allMazes() {
		return mDataBase.query(DATABASE_TABLE, COLUMNS,
		/* selection: */null,
		/* selectionArgs: */null,
		/* groupBy: */null,
		/* having: */null,
		/* orderBy: */KEY_ID);
	}

	public Cursor unsolvedMazes() {
		return mDataBase.query(DATABASE_TABLE,
		/* :columns: */new String[] { KEY_ID },
		/* selection: */KEY_SOLUTION_STEPS + " = ?",
		/* selectionArgs: */new String[] { "0" },
		/* groupBy: */null,
		/* having: */null,
		/* orderBy: */KEY_ID);
	}

	/**
	 * method to get the first unsolved maze
	 * 
	 * @return
	 */
	public int getFirstUnsolved() {
		Cursor c = unsolvedMazes();

		// if there are no more unsolved mazes
		if (!c.moveToFirst()) {
			// There are no more unsolved mazes
			return 0;
		}

		return c.getInt(ID_COLUMN);
	}

	private static class AMazeDBOpenHelper extends SQLiteOpenHelper {
		private static final String DATABASE_CREATE = "create table "
				+ DATABASE_TABLE + " (" + KEY_ID
				+ " integer primary key autoincrement, " + KEY_NAME
				+ " text not null, " + KEY_SOLUTION_STEPS + " integer" + ", "
				+ KEY_TIME_TAKEN + " integer" + ");";

		public AMazeDBOpenHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
		}

		/**
		 * on create method which has the database passed in to execute SQL
		 * create database
		 */
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);

			db.beginTransaction();
			try {
				ContentValues values = new ContentValues();
				values.put(KEY_SOLUTION_STEPS, 0);
				values.put(KEY_TIME_TAKEN, 0);
				
				int id = 0;
				for (MapDesign map : MapDesigns.designList) {
					values.put(KEY_ID, id);
					values.put(KEY_NAME, map.getName());
					db.insert(DATABASE_TABLE, null, values);
					id = id + 1;
				}

				db.setTransactionSuccessful();

				// execute the finally statement even if the previous code does
				// not execute
			} finally {
				db.endTransaction();
			}
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

			db.execSQL("drop table if exists " + DATABASE_TABLE);
			onCreate(db);
		}

	}
}
