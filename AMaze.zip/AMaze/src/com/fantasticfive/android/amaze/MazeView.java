package com.fantasticfive.android.amaze;

import java.util.Timer;
import java.util.TimerTask;

import com.fantasticfive.android.amaze.R;
import com.fantasticfive.android.amaze.R.color;
import com.fantasticfive.android.amaze.R.drawable;

import android.view.View;
import android.widget.LinearLayout;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.RadialGradient;
import android.graphics.drawable.shapes.RectShape;
import android.media.MediaPlayer;
import android.os.SystemClock;
import android.util.AttributeSet;

/**
 * 
 * @author FantasticFive
 * 
 */
public class MazeView extends View {
	private boolean DEBUG = false;

	private static final float WALL_WIDTH = 5;

	private GameEngine mGameEngine;

	private Ball mBall;
	private float mBallX;
	private float mBallY;

	private int mWidth;
	private float mXMin;
	private float mYMin;
	private float mXMax;
	private float mYMax;
	private float mUnit;

	private int mMapWidth;
	private int mMapHeight;
	private int[][] mWalls;
	private int[][] mGoals;

	private Paint paint;
	private Matrix matrix = new Matrix();
	private Matrix scaleMatrix = new Matrix();

	private MediaPlayer Mplayer;
	
	private Timer mTimer;
	private long mT1 = 0;
	private long mT2 = 0;
	private int mDrawStep = 0;
	private int mDrawTimeHistorySize = 20;
	private long[] mDrawTimeHistory = new long[mDrawTimeHistorySize];

	public MazeView(Context context, AttributeSet attrs) {
		super(context, attrs);

		// Set up default Paint values
		paint = new Paint();
		paint.setAntiAlias(true);

		// Calculate geometry
		int w = getWidth();
		int h = getHeight();
		mWidth = Math.min(w, h);
		mXMin = WALL_WIDTH / 2;
		mYMin = WALL_WIDTH / 2;
		mXMax = Math.min(w, h) - WALL_WIDTH / 2;
		mYMax = mXMax;

		if (DEBUG) {
			// Schedule a redraw at 25 Hz
			TimerTask redrawTask = new TimerTask() {
				public void run() {
					postInvalidate();
				}
			};
			mTimer = new Timer(true);
			mTimer.schedule(redrawTask, 0, 1000/* ms *// 25);
		}
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		mWidth = Math.min(w, h);
		mXMax = Math.min(w, h) - WALL_WIDTH / 2;
		mYMax = mXMax;

		calculateUnit();
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		mWidth = Math.min(getMeasuredWidth(), getMeasuredHeight());
		setMeasuredDimension(mWidth, mWidth);
	}

	@Override
	public void onDraw(Canvas canvas) {
		// FPS stats
		mT2 = SystemClock.elapsedRealtime();
		long dt = (mT2 - mT1);
		mT1 = mT2;
		mDrawTimeHistory[mDrawStep % mDrawTimeHistorySize] = dt;
		mDrawStep = mDrawStep + 1;

		mBall = mGameEngine.getBall();
		mMapWidth = mGameEngine.getMap().getSizeX();
		mMapHeight = mGameEngine.getMap().getSizeY();

		drawWalls(canvas);
		drawGoals(canvas);
		drawBall(canvas);

		if (DEBUG) {
			// Print FPS
			paint.setColor(Color.WHITE);
			paint.setStyle(Style.STROKE);
			paint.setStrokeWidth(1);
			canvas.drawText("FPS: " + getFPS(), 20, 30, paint);
		}
	}

	public void setGameEngine(GameEngine e) {
		mGameEngine = e;

	}

	public void calculateUnit() {
		if (mGameEngine == null)
			return;

		// Set up geometry
		float xUnit = ((mXMax - mXMin) / mGameEngine.getMap().getSizeX());
		float yUnit = ((mYMax - mYMin) / mGameEngine.getMap().getSizeY());
		mUnit = Math.min(xUnit, yUnit);
	}

	public double getFPS() {
		double avg = 0;
		int n = 0;
		for (long t : mDrawTimeHistory) {
			if (t > 0) {
				avg = avg + t;
				n = n + 1;
			}
		}
		if (n == 0)
			return -1;
		return 1000 * n / avg;
	}

	@SuppressLint("ResourceAsColor")
	private void drawWalls(Canvas canvas) {

		// set of if statements to work out if its is certain map load certain
		// wall colours
		if (mGameEngine.getMap().getName().equalsIgnoreCase("APPvengers")) {
			setBackgroundResource(drawable.avengers);
			paint.setColor(getResources().getColor(R.color.wall_Avengers));
	
		
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Iron Man")) {
			setBackgroundResource(drawable.ironman);
			paint.setColor(getResources().getColor(R.color.wall_Iron));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Captain A")) {
			setBackgroundResource(drawable.captainamerica);
			paint.setColor(getResources().getColor(R.color.wall_Captain));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Loki")) {
			setBackgroundResource(drawable.loki_avengers);
			paint.setColor(getResources().getColor(R.color.wall_Loki));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Nick Fury")) {
			setBackgroundResource(drawable.fury);
			paint.setColor(getResources().getColor(R.color.wall_Nick));
		} else if (mGameEngine.getMap().getName()
				.equalsIgnoreCase("Black Widow")) {
			setBackgroundResource(drawable.blackwidow);
			paint.setColor(getResources().getColor(R.color.wall_Black));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Hawkeye")) {
			setBackgroundResource(drawable.hawkeye);
			paint.setColor(getResources().getColor(R.color.wall_Hawk));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Scarlett Witch")) {
			setBackgroundResource(drawable.scarletwitch);
			paint.setColor(getResources().getColor(R.color.wall_Scarlett_Witch));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("The Hulk")) {
			setBackgroundResource(drawable.hulk);
			paint.setColor(getResources().getColor(R.color.wall_Hulk));
		} else if (mGameEngine.getMap().getName()
				.equalsIgnoreCase("Quicksilver")) {
			setBackgroundResource(drawable.quicksilver);
			paint.setColor(getResources().getColor(R.color.wall_Quick));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("thor")) {
			setBackgroundResource(drawable.thor);
			paint.setColor(getResources().getColor(R.color.wall_Thor));
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Ultron")) {
			setBackgroundResource(drawable.ultron);
			paint.setColor(getResources().getColor(R.color.wall_Ultron));
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Thanos")) {
			setBackgroundResource(drawable.thanos);
			paint.setColor(getResources().getColor(R.color.wall_Thanos));
		}

		// once that is done then continue on creating the walls
		paint.setStrokeWidth(WALL_WIDTH);
		paint.setStrokeCap(Cap.ROUND);

		mWalls = mGameEngine.getMap().getWalls();

		for (int y = 0; y < mMapHeight; y++) {
			for (int x = 0; x < mMapWidth; x++) {
				if ((mWalls[y][x] & Wall.TOP) > 0) {
					canvas.drawLine(mXMin + x * mUnit, mYMin + y * mUnit, mXMin
							+ (x + 1) * mUnit, mYMin + y * mUnit, paint);
				}
				if ((mWalls[y][x] & Wall.RIGHT) > 0) {
					canvas.drawLine(mXMin + (x + 1) * mUnit, mYMin + y * mUnit,
							mXMin + (x + 1) * mUnit, mYMin + (y + 1) * mUnit,
							paint);
				}
				if ((mWalls[y][x] & Wall.BOTTOM) > 0) {
					canvas.drawLine(mXMin + x * mUnit, mYMin + (y + 1) * mUnit,
							mXMin + (x + 1) * mUnit, mYMin + (y + 1) * mUnit,
							paint);
				}
				if ((mWalls[y][x] & Wall.LEFT) > 0) {
					canvas.drawLine(mXMin + x * mUnit, mYMin + y * mUnit, mXMin
							+ x * mUnit, mYMin + (y + 1) * mUnit, paint);
				}
			}
		}

		paint.setShader(null);
	}

	/**
	 * drawig the goals
	 * 
	 * @param canvas
	 */
	private void drawGoals(Canvas canvas) {

		// due to the nature of how the goal is created to determine colour the
		// entire code must go in to the if statements to ensure correctly
		// executed
		if (mGameEngine.getMap().getName().equalsIgnoreCase("APPvengers")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Avengers),
					getResources().getColor(R.color.goal_shadow_Avengers),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Iron Man")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Iron),
					getResources().getColor(R.color.goal_shadow_Iron),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Captain A")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Captain),
					getResources().getColor(R.color.goal_shadow_Captain),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Loki")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Loki),
					getResources().getColor(R.color.goal_shadow_Loki),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Nick Fury")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Nick),
					getResources().getColor(R.color.goal_shadow_Nick),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Thanos")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Thanos),
					getResources().getColor(R.color.goal_shadow_Thanos),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Black Widow")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Black),
					getResources().getColor(R.color.goal_shadow_Black),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Hawkeye")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Hawk),
					getResources().getColor(R.color.goal_shadow_Hawk),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Scarlett Witch")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Scarlett_Witch),
					getResources().getColor(R.color.goal_shadow_Scarlett_Witch),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("The Hulk")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Hulk),
					getResources().getColor(R.color.goal_shadow_Hulk),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Quicksilver")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Quick),
					getResources().getColor(R.color.goal_shadow_Quick),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("thor")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Thor),
					getResources().getColor(R.color.goal_shadow_Thor),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Ultron")) {
			RadialGradient goalGradient = new RadialGradient(0, 0, 1,
					getResources().getColor(R.color.goal_highlight_Ultron),
					getResources().getColor(R.color.goal_shadow_Ultron),
					TileMode.MIRROR);

			paint.setShader(goalGradient);
			paint.setStyle(Style.STROKE);
			scaleMatrix.setScale(mUnit, mUnit);

			mGoals = mGameEngine.getMap().getGoals();

			for (int y = 0; y < mMapHeight; y++) {
				for (int x = 0; x < mMapWidth; x++) {
					if (mGoals[y][x] > 0) {
						matrix.setTranslate(mXMin + x * mUnit, mYMin + y
								* mUnit);
						matrix.setConcat(matrix, scaleMatrix);
						goalGradient.setLocalMatrix(matrix);
						canvas.drawRect(mXMin + x * mUnit + mUnit / 4, mYMin
								+ y * mUnit + mUnit / 4, mXMin + (x + 1)
								* mUnit - mUnit / 4, mYMin + (y + 1) * mUnit
								- mUnit / 4, paint);
					}
				}
			}

			paint.setShader(null);
		}
	}

	private void drawBall(Canvas canvas) {

		// set of if statements to determine if the map name is a certain maze
		// load a certain colour set for ball
		if (mGameEngine.getMap().getName().equalsIgnoreCase("APPvengers")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Avengers),
					getResources().getColor(R.color.ball_shadow_Avengers),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Iron Man")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Iron),
					getResources().getColor(R.color.ball_shadow_Iron),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Captain A")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Captain),
					getResources().getColor(R.color.ball_shadow_Captain),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		} else if (mGameEngine.getMap().getName().equalsIgnoreCase("Loki")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Loki),
					getResources().getColor(R.color.ball_shadow_Loki),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Nick Fury")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Nick),
					getResources().getColor(R.color.ball_shadow_Nick),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Thanos")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Thanos),
					getResources().getColor(R.color.ball_shadow_Thanos),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Black Widow")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Black),
					getResources().getColor(R.color.ball_shadow_Black),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Hawkeye")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Hawk),
					getResources().getColor(R.color.ball_shadow_Hawk),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Scarlett Witch")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Scarlett_Witch),
					getResources().getColor(R.color.ball_shadow_Scarlett_Witch),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("The Hulk")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Hulk),
					getResources().getColor(R.color.ball_shadow_Hulk),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Quicksilver")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Quick),
					getResources().getColor(R.color.ball_shadow_Quick),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("Ultron")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Ultron),
					getResources().getColor(R.color.ball_shadow_Ultron),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}else if (mGameEngine.getMap().getName().equalsIgnoreCase("thor")) {

			mBallX = mBall.getX();
			mBallY = mBall.getY();

			paint.setShader(new RadialGradient(
					mXMin + (mBallX + 0.55f) * mUnit, mYMin + (mBallY + 0.55f)
							* mUnit, mUnit * 0.35f,

					getResources().getColor(R.color.ball_highlight_Thor),
					getResources().getColor(R.color.ball_shadow_Thor),
					TileMode.MIRROR));

			paint.setStyle(Style.FILL);
			canvas.drawCircle(mXMin + (mBallX + 0.5f) * mUnit, mYMin
					+ (mBallY + 0.5f) * mUnit, mUnit * 0.4f, paint);
			paint.setShader(null);
		}
	}

}