
package com.fantasticfive.android.amaze;

// ENUMs for direction ball can move in
public enum Direction {
	NONE,
	LEFT,
	RIGHT,
	UP,
	DOWN
}
